# Exp 13 – GPG Email Security (Linux)

**Part A is automatic. Part B is what you do by hand for your record.**

## Part A – Let the script do the setup (1 command)

```bash
cd lab_experiments
./run.sh        # choose 13 -> 1
# or directly:
./exp13_gpg_setup.sh
```

The script installs GnuPG (asks for your sudo password once), creates two test users
(**Student** = sender, **Recipient**) in separate keyrings under `~/gpg_lab`, then runs:
list keys -> export/import public keys -> encrypt -> decrypt -> sign -> verify -> tamper test.
Everything printed is also saved in `~/gpg_lab/exp13_output.log`.
Your real `~/.gnupg` is not touched.

Folder layout after running:

```
~/gpg_lab/student/    email.txt, email.txt.asc, student_public_key.asc, signed_email.txt(.asc)
~/gpg_lab/recipient/  recipient_public_key.asc, received copies
```

## Part B – Manual run for screenshots (what your report needs)

Open **two terminals**. Terminal 1 = Student, Terminal 2 = Recipient.
Using `GNUPGHOME` gives each terminal its own keyring (no second Linux user needed).

**Terminal 1 (Student):**
```bash
mkdir -p ~/gpg_manual/student ~/gpg_manual/recipient && chmod 700 ~/gpg_manual/student ~/gpg_manual/recipient
export GNUPGHOME=~/gpg_manual/student
cd ~/gpg_manual/student
```
**Terminal 2 (Recipient):**
```bash
export GNUPGHOME=~/gpg_manual/recipient
cd ~/gpg_manual/recipient
```

| # | Where | Command | Screenshot? |
|---|-------|---------|-------------|
| 1 | both | `gpg --version` | ✅ |
| 2 | T1 | `gpg --full-generate-key` -> choose **1 (RSA and RSA)**, size **3072**, validity **0**, Name `Student`, Email `student@example.com`, `O` (Okay), set a passphrase | ✅ |
| 3 | T2 | same command, Name `Recipient`, Email `recipient@example.com` | ✅ |
| 4 | T1 | `gpg --list-keys` and `gpg --list-secret-keys` | ✅ |
| 5 | T1 | `gpg --armor --export student@example.com > student_public_key.asc` then `cat student_public_key.asc` | ✅ |
| 6 | T2 | `gpg --armor --export recipient@example.com > recipient_public_key.asc` | |
| 7 | both | Copy each `.asc` to the other folder: `cp ~/gpg_manual/recipient/recipient_public_key.asc ~/gpg_manual/student/` and `cp ~/gpg_manual/student/student_public_key.asc ~/gpg_manual/recipient/` | |
| 8 | T1 | `gpg --import recipient_public_key.asc` then `gpg --list-keys` | ✅ |
| 9 | T1 | `nano email.txt` – paste the sample email (below), save with Ctrl+O, Enter, Ctrl+X | ✅ |
| 10 | T1 | `gpg --armor --encrypt --recipient recipient@example.com email.txt` -> if asked *"Use this key anyway?"* type `y` | ✅ |
| 11 | T1 | `ls` then `cat email.txt.asc` (starts with `-----BEGIN PGP MESSAGE-----`) | ✅ |
| 12 | T1 | `cp email.txt.asc ~/gpg_manual/recipient/` | |
| 13 | T2 | `gpg --decrypt email.txt.asc` -> enter the Recipient passphrase | ✅ |
| 14 | T1 | `nano signed_email.txt` (any short text), then `gpg --armor --detach-sign signed_email.txt`, enter passphrase | ✅ |
| 15 | T1 | `cp signed_email.txt signed_email.txt.asc ~/gpg_manual/recipient/` | |
| 16 | T2 | `gpg --import student_public_key.asc` | |
| 17 | T2 | `gpg --verify signed_email.txt.asc signed_email.txt` -> must say **Good signature** | ✅ |
| 18 | T2 | *(Bonus)* `echo hacked >> signed_email.txt` then verify again -> **BAD signature** | ✅ |

Sample email for step 9:
```
Subject: Confidential Project Discussion

Dear Team,

This is a confidential message for our project discussion.
The contents of this message should only be accessible
to the intended recipient.

Regards,
Student
```

### Quick fixes
- **"Use this key anyway?"** – normal for a freshly imported key; answer `y` (or add `--trust-model always`).
- **Passphrase window doesn't appear over SSH** – run `export GPG_TTY=$(tty)` first.
- **"unsafe permissions on homedir"** – `chmod 700 $GNUPGHOME`.
- **Good signature shows `[unknown]`** – expected, the key isn't certified. Mention this in your report (the doc's sample output has the same).
- Key IDs/timestamps will differ from the sample output in your doc – use your own screenshots.
