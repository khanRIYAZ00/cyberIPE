# Network Security Lab – Experiments 7, 8, 9, 13, 16

```bash
chmod +x *.sh      # once
./run.sh           # pick the experiment number from the menu
```

| Exp | What | How |
|-----|------|-----|
| 7  | RSA | runs `exp07_rsa.py` |
| 8  | Diffie-Hellman | runs `exp08_diffie_hellman.py` |
| 9  | MD5 | runs `exp09_md5.py` |
| 13 | GPG | `exp13_gpg_setup.sh` + `README_exp13_GPG.md` |
| 16 | Wireshark | `exp16_wireshark_setup.sh` + `README_exp16_Wireshark.md` |

Requires Python 3 (exp 7-9) and an Ubuntu/Debian/Kali-style Linux with sudo (exp 13, 16).
