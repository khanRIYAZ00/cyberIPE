# Exp 16 – Wireshark Packet Analysis Using Filters

**Part A is automatic (install + sample captures). Part B is the GUI work you do for screenshots.**

## Part A – Automatic setup (1 command)

```bash
cd lab_experiments
./run.sh        # choose 16 -> 1
# or directly:
./exp16_wireshark_setup.sh
```

It will (asks for your sudo password):
1. Install Wireshark + tshark and pre-answer *"allow non-superusers to capture"* with **Yes**
2. Add you to the `wireshark` group
3. Detect your active interface (Wi-Fi/Ethernet)
4. Record `~/wireshark_lab/full_capture.pcapng` (15 s, DNS + ping + HTTP + HTTPS traffic generated for you)
5. Record `~/wireshark_lab/dns_only_capture.pcapng` using the capture filter `port 53`
6. Print a table of how many packets each display filter matches

> **Log out and log in once** (or reboot) afterwards so the `wireshark` group applies and you can capture live without `sudo`.
> Needs an Ubuntu/Debian/Kali system. If the apt install fails, run `sudo apt update` and retry.

## Part B – What you do in Wireshark (screenshots)

### B1. Open the capture (Section 5 of your doc)
```bash
wireshark -r ~/wireshark_lab/full_capture.pcapng &
```
📸 Screenshot the main window.

*(To record live traffic yourself instead: run `wireshark`, double-click your interface (e.g. `wlan0`/`eth0`), open a website, then click the red **Stop** button.)*

### B2. Display filters (Section 6) – type in the green bar at the top, press **Enter**
Clear it (✕ button) between filters. 📸 One screenshot per filter.

| Filter | Shows |
|--------|-------|
| `dns` | DNS queries/responses |
| `http` | HTTP (from the `curl http://example.com` request) |
| `tcp` | All TCP |
| `udp` | All UDP |
| `icmp` | Ping packets |
| `ip.addr == <your IP>` | Packets to **or** from that IP |
| `ip.src == <your IP>` | Packets **from** that IP |
| `ip.dst == <your IP>` | Packets **to** that IP |
| `tcp.port == 443` | HTTPS |
| `dns && ip` | DNS **and** IPv4 |
| `tcp.flags.syn == 1` | TCP connection starts |

Find your IP with `ip -4 addr` (it is also printed by the script; the script’s table uses the same filters). Turning the bar **green** means the filter is valid; **red** means a syntax error.

### B3. Capture filters (Section 7)
Capture filters are set **before** capture starts and use different syntax.
1. Start Wireshark: `wireshark`
2. In the interface list, type the filter in **"Enter a capture filter"** (e.g. `port 53`) and double-click the interface.
3. Generate traffic: `nslookup example.com`
4. Stop with the red square.

Try each: `host 8.8.8.8`, `port 53`, `tcp`, `net 192.168.1.0/24` (replace with your own network).
📸 Screenshot the capture-filter box and the resulting packet list.
A ready-made example is in `~/wireshark_lab/dns_only_capture.pcapng`.

### B4. Trace and inspect one packet (Sections 8–9)
1. Apply `dns`.
2. Click one packet.
3. In **Packet Details**, expand *Frame*, *Ethernet II*, *Internet Protocol*, *User Datagram Protocol*, *Domain Name System*. Note source/destination addresses, ports, query name, and whether it is a **Query** or **Response**.
4. Look at **Packet Bytes** (hex + ASCII).
5. Clear the filter to return to the full list.
📸 Screenshot the expanded details.
Repeat with `tcp` (note flags) and `icmp` (Echo request/reply).

### B5. Finish the report
- **Observation/Result:** write which filters you applied and how the packet list narrowed; use your own screenshots and packet counts (they will differ from anyone else's).
- Keep the packet-count table the script printed as supporting output.

### Troubleshooting
- **"You don't have permission to capture on that device"** – log out/in after Part A, or run `sudo dpkg-reconfigure wireshark-common` (choose **Yes**), then `sudo usermod -aG wireshark $USER` and re-login.
- **No interface listed** – run `ip link`; make sure Wi-Fi/Ethernet is up.
- **`http` shows 0 packets** – most sites use HTTPS; `curl http://example.com` generates plain HTTP. Re-run the script or visit an `http://` site.
- **Headless/SSH machine** – use `tshark -r ~/wireshark_lab/full_capture.pcapng -Y "dns"` instead of the GUI.
