#!/usr/bin/env bash
# =============================================================================
# Exp 16 - Wireshark Packet Filters: automated setup
#  1. Installs Wireshark + tshark (allows non-root capture)
#  2. Records two sample captures while generating DNS/HTTP/HTTPS/ICMP traffic
#  3. Shows how many packets each display filter from the lab matches
# Files go to ~/wireshark_lab.  You only need to open Wireshark afterwards
# and apply the filters yourself (see README_exp16_Wireshark.md).
# =============================================================================
set -uo pipefail

LAB="$HOME/wireshark_lab"
FULL="$LAB/full_capture.pcapng"
DNSONLY="$LAB/dns_only_capture.pcapng"
mkdir -p "$LAB"
step() { echo; echo "================ $* ================"; }

command -v apt-get >/dev/null || { echo "This script needs an apt-based distro (Ubuntu/Debian/Kali)."; exit 1; }
sudo -v || { echo "sudo is required."; exit 1; }

# ---------- 1. Install -------------------------------------------------------
step "1. Installing Wireshark, tshark and helper tools"
sudo apt-get update -y
# Pre-answer the "allow non-superusers to capture packets?" question with YES
echo "wireshark-common wireshark-common/install-setuid boolean true" | sudo debconf-set-selections
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y wireshark tshark curl iputils-ping
sudo apt-get install -y dnsutils 2>/dev/null || sudo apt-get install -y bind9-dnsutils
sudo usermod -aG wireshark "$USER" 2>/dev/null || true
wireshark --version 2>/dev/null | head -n 1 || tshark --version | head -n 1

# ---------- 2. Pick interface ------------------------------------------------
step "2. Detecting active network interface"
IFACE="$(ip route show default 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
[ -z "${IFACE:-}" ] && IFACE="$(tshark -D 2>/dev/null | head -n1 | sed -E 's/^[0-9]+\. ([^ ]+).*/\1/')"
LOCALIP="$(ip -4 addr show dev "$IFACE" 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1)"
echo "Interface: $IFACE    Local IP: ${LOCALIP:-unknown}"

traffic() {
    sleep 2
    ping -c 4 8.8.8.8            >/dev/null 2>&1
    nslookup example.com         >/dev/null 2>&1
    nslookup wireshark.org       >/dev/null 2>&1
    curl -s http://example.com   -o /dev/null
    curl -s https://example.com  -o /dev/null
    ping -c 3 example.com        >/dev/null 2>&1
}

# ---------- 3. Capture -------------------------------------------------------
step "3a. Capturing ALL traffic for 15 s (no capture filter)"
sudo tshark -i "$IFACE" -a duration:15 -w "$FULL" -q 2>/dev/null &
CAP=$!; traffic; wait $CAP
sudo chown "$USER":"$USER" "$FULL" 2>/dev/null

step "3b. Capturing with CAPTURE FILTER 'port 53' for 8 s"
sudo tshark -i "$IFACE" -f "port 53" -a duration:8 -w "$DNSONLY" -q 2>/dev/null &
CAP=$!; sleep 2; nslookup example.com >/dev/null 2>&1; nslookup wireshark.org >/dev/null 2>&1; wait $CAP
sudo chown "$USER":"$USER" "$DNSONLY" 2>/dev/null

# ---------- 4. Demo display filters -----------------------------------------
step "4. Display-filter results on full_capture.pcapng"
filters=( "dns" "http" "tcp" "udp" "icmp"
          "ip.addr == ${LOCALIP:-192.168.1.1}" "ip.src == ${LOCALIP:-192.168.1.1}" "ip.dst == ${LOCALIP:-192.168.1.1}"
          "tcp.port == 443" "dns && ip" "tcp.flags.syn == 1" )
printf "%-34s %s\n" "FILTER" "PACKETS"
for f in "${filters[@]}"; do
    n=$(tshark -r "$FULL" -Y "$f" 2>/dev/null | wc -l)
    printf "%-34s %s\n" "$f" "$n"
done
echo; echo "--- First DNS packets ---";  tshark -r "$FULL" -Y dns  2>/dev/null | head -n 6
echo; echo "--- First ICMP packets ---"; tshark -r "$FULL" -Y icmp 2>/dev/null | head -n 4
echo; echo "Packets in dns_only_capture.pcapng (capture filter 'port 53'): $(tshark -r "$DNSONLY" 2>/dev/null | wc -l)"

# ---------- Done -------------------------------------------------------------
step "DONE"
ls -l "$LAB"
echo "NOTE: log out and back in (or reboot) once so the 'wireshark' group lets you capture live without sudo."
echo "Next: follow README_exp16_Wireshark.md (open the .pcapng files, apply filters, take screenshots)."
if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
    read -rp "Open full_capture.pcapng in Wireshark now? [y/N] " a
    [[ "$a" =~ ^[Yy]$ ]] && { nohup wireshark -r "$FULL" >/dev/null 2>&1 & }
fi
