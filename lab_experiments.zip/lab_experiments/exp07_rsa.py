# Experiment 7: Implement RSA Algorithm
import math


def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a


def mod_inverse(e, phi):
    """Finds d such that (d * e) % phi == 1 using extended Euclidean algorithm"""
    d_old, d_new = 0, 1
    r_old, r_new = phi, e

    while r_new != 0:
        quotient = r_old // r_new
        r_old, r_new = r_new, r_old - quotient * r_new
        d_old, d_new = d_new, d_old - quotient * d_new

    if r_old > 1:
        return None  # e and phi are not coprime
    if d_old < 0:
        d_old += phi
    return d_old


def generate_keypair(p, q):
    n = p * q
    phi = (p - 1) * (q - 1)

    # Choose e such that 1 < e < phi and gcd(e, phi) == 1
    e = 3
    while gcd(e, phi) != 1:
        e += 2

    # Calculate d
    d = mod_inverse(e, phi)

    return ((e, n), (d, n), phi)


def encrypt(public_key, plaintext):
    e, n = public_key
    # Encrypt each character using C = (M^e) mod n
    return [pow(ord(char), e, n) for char in plaintext]


def decrypt(private_key, ciphertext):
    d, n = private_key
    # Decrypt each character using M = (C^d) mod n
    return "".join(chr(pow(c, d, n)) for c in ciphertext)


# Driver Program
if __name__ == "__main__":
    # Step 1: Select two prime numbers
    p = 61
    q = 53

    print(f"1. Prime Numbers Selected: p = {p}, q = {q}")

    # Step 2 & 3: Key generation
    public_key, private_key, phi = generate_keypair(p, q)
    n = public_key[1]

    print(f"2. Calculated Modulus (n) = {n}")
    print(f"3. Calculated Euler's Totient phi(n) = {phi}")
    print(f"4. Public Key (e, n): {public_key}")
    print(f"5. Private Key (d, n): {private_key}")

    # Message input
    message = "RSA"
    print(f"\nOriginal Message: {message}")

    # Step 4: Encryption
    encrypted_msg = encrypt(public_key, message)
    print(f"Encrypted Ciphertext: {encrypted_msg}")

    # Step 5: Decryption
    decrypted_msg = decrypt(private_key, encrypted_msg)
    print(f"Decrypted Message: {decrypted_msg}")
