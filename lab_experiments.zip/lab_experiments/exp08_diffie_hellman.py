# Experiment 8: Implement Diffie-Hellman Key Exchange Algorithm

# Step 1: Publicly agreed prime number and primitive root
p = 23
g = 5

# Step 2: Private keys chosen by Alice and Bob
a = 6
b = 15

print(f"1. Public Prime Number (p): {p}")
print(f"2. Public Primitive Root (g): {g}")
print(f"3. Alice's Private Key (a): {a}")
print(f"4. Bob's Private Key (b): {b}")

# Step 3: Calculate public keys
A = pow(g, a, p)  # Alice's public key
B = pow(g, b, p)  # Bob's public key

print(f"5. Alice's Public Key (A): {A}")
print(f"6. Bob's Public Key (B): {B}")

# Step 4: Calculate the shared secret key
alice_shared_key = pow(B, a, p)
bob_shared_key = pow(A, b, p)

print(f"7. Alice's Shared Secret Key: {alice_shared_key}")
print(f"8. Bob's Shared Secret Key: {bob_shared_key}")

if alice_shared_key == bob_shared_key:
    print("Key Exchange Successful: Shared keys match.")
else:
    print("Key Exchange Failed: Shared keys do not match.")
