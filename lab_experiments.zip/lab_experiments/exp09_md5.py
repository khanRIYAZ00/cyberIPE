# Experiment 9: Generate hash value for input data using MD5
import hashlib

# Input data
data = "Hello, World!"

# Generate MD5 hash
# 1. Encode string to bytes
# 2. Pass bytes to hashlib.md5()
# 3. Get the hexadecimal representation
md5_hash = hashlib.md5(data.encode("utf-8")).hexdigest()

print(f"MD5 Hash: {md5_hash}")
