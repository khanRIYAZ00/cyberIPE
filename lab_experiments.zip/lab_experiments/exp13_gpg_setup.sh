#!/usr/bin/env bash
# =============================================================================
# Exp 13 - GPG Email Security: automated setup + full demo
# Installs GnuPG, creates TWO test users (student = sender, recipient),
# then runs: export/import keys -> encrypt -> decrypt -> sign -> verify.
# Everything is saved in ~/gpg_lab (output log: ~/gpg_lab/exp13_output.log)
# Your real ~/.gnupg keyring is NOT touched.
# =============================================================================
set -euo pipefail

LAB="$HOME/gpg_lab"
S_NAME="${S_NAME:-Student}";     S_EMAIL="${S_EMAIL:-student@example.com}"
R_NAME="${R_NAME:-Recipient}";   R_EMAIL="${R_EMAIL:-recipient@example.com}"

S_HOME="$LAB/keyring_student"      # student's private GnuPG home
R_HOME="$LAB/keyring_recipient"    # recipient's private GnuPG home
S_DIR="$LAB/student"               # student's working folder
R_DIR="$LAB/recipient"             # recipient's working folder

S() { gpg --homedir "$S_HOME" --batch --yes "$@"; }
R() { gpg --homedir "$R_HOME" --batch --yes "$@"; }
step() { echo; echo "================ $* ================"; }

# ---------- 1. Install GPG ---------------------------------------------------
step "1. Install GPG"
if ! command -v gpg >/dev/null 2>&1; then
    command -v apt-get >/dev/null || { echo "apt-get not found - install gnupg manually."; exit 1; }
    sudo apt-get update -y
    sudo apt-get install -y gnupg
fi
gpg --version | head -n 2

mkdir -p "$S_HOME" "$R_HOME" "$S_DIR" "$R_DIR"
chmod 700 "$S_HOME" "$R_HOME"
exec > >(tee "$LAB/exp13_output.log") 2>&1

# ---------- 2. Generate key pairs -------------------------------------------
step "2. Generate key pairs (RSA 3072, no expiry) for both users"
gen_key() {  # $1=homedir  $2=name  $3=email
    if gpg --homedir "$1" --list-keys "$3" >/dev/null 2>&1; then
        echo "Key for $3 already exists - skipping."
    else
        gpg --homedir "$1" --batch --pinentry-mode loopback --passphrase '' \
            --quick-generate-key "$2 <$3>" rsa3072 sign,cert 0
        local fpr
        fpr=$(gpg --homedir "$1" --list-keys --with-colons "$3" | awk -F: '/^fpr:/ {print $10; exit}')
        gpg --homedir "$1" --batch --pinentry-mode loopback --passphrase '' \
            --quick-add-key "$fpr" rsa3072 encr 0
    fi
}
gen_key "$S_HOME" "$S_NAME" "$S_EMAIL"
gen_key "$R_HOME" "$R_NAME" "$R_EMAIL"

# ---------- 3. List keys -----------------------------------------------------
step "3. List the keys (student's keyring)"
S --list-keys
S --list-secret-keys

# ---------- 4. Export / import public keys ----------------------------------
step "4. Export public keys and import them into each other's keyring"
S --armor --export "$S_EMAIL" > "$S_DIR/student_public_key.asc"
R --armor --export "$R_EMAIL" > "$R_DIR/recipient_public_key.asc"
head -n 4 "$S_DIR/student_public_key.asc"; echo "   ... (public key exported to student_public_key.asc)"

S --import "$R_DIR/recipient_public_key.asc"   # student imports recipient's key
R --import "$S_DIR/student_public_key.asc"     # recipient imports student's key
echo; echo "Student's keyring now contains:"; S --list-keys

# ---------- 5. Create sample email ------------------------------------------
step "5. Create sample email"
cat > "$S_DIR/email.txt" <<'MAIL'
Subject: Confidential Project Discussion

Dear Team,

This is a confidential message for our project discussion.
The contents of this message should only be accessible
to the intended recipient.

Regards,
Student
MAIL
cat "$S_DIR/email.txt"

# ---------- 6. Encrypt -------------------------------------------------------
step "6. Encrypt email with the RECIPIENT's public key"
( cd "$S_DIR" && rm -f email.txt.asc &&
  S --armor --trust-model always --encrypt --recipient "$R_EMAIL" email.txt )
ls -l "$S_DIR"
echo; cat "$S_DIR/email.txt.asc"
cp "$S_DIR/email.txt.asc" "$R_DIR/"      # "send" the email to recipient

# ---------- 7. Decrypt -------------------------------------------------------
step "7. Decrypt as RECIPIENT (uses recipient's private key)"
R --decrypt "$R_DIR/email.txt.asc"

# ---------- 8. Sign ----------------------------------------------------------
step "8. Digitally sign a message as STUDENT (detached signature)"
cat > "$S_DIR/signed_email.txt" <<'MAIL'
Subject: Signed Message

This message is signed by Student to prove authenticity and integrity.
MAIL
( cd "$S_DIR" && rm -f signed_email.txt.asc &&
  S --armor --detach-sign signed_email.txt )
ls -l "$S_DIR"
cp "$S_DIR/signed_email.txt" "$S_DIR/signed_email.txt.asc" "$R_DIR/"

# ---------- 9. Verify --------------------------------------------------------
step "9. Verify the signature as RECIPIENT"
R --verify "$R_DIR/signed_email.txt.asc" "$R_DIR/signed_email.txt"
echo ">>> Look for: 'Good signature from \"Student <student@example.com>\"'"

# ---------- 10. Bonus: tamper test ------------------------------------------
step "10. BONUS - tamper with the message and verify again (must FAIL)"
cp "$R_DIR/signed_email.txt" "$R_DIR/tampered_email.txt"
echo "Extra line added by attacker" >> "$R_DIR/tampered_email.txt"
R --verify "$R_DIR/signed_email.txt.asc" "$R_DIR/tampered_email.txt" || \
    echo ">>> BAD signature detected - integrity check works."

# ---------- cleanup & summary -----------------------------------------------
gpgconf --homedir "$S_HOME" --kill gpg-agent 2>/dev/null || true
gpgconf --homedir "$R_HOME" --kill gpg-agent 2>/dev/null || true

step "DONE"
echo "Files:    $LAB"
echo "Log:      $LAB/exp13_output.log"
echo "Next:     follow README_exp13_GPG.md  (Part B - screenshots + manual run)"
