#!/usr/bin/env bash
# Lab experiment launcher - pick an experiment and it runs.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python)"

pause() { echo; read -rp "Press Enter to return to the menu..." _; }

sub_menu() {   # $1=title  $2=setup script  $3=readme
    echo; echo "  $1"
    echo "    1) Run automated setup / demo"
    echo "    2) Show step-by-step guide (README)"
    echo "    b) Back"
    read -rp "  Choose: " s
    case "$s" in
        1) bash "$DIR/$2" ;;
        2) "${PAGER:-cat}" "$DIR/$3" ;;
        *) return ;;
    esac
}

while true; do
    clear 2>/dev/null
    cat <<'MENU'
=============================================
   NETWORK SECURITY LAB - Khan Mohd Riyaz
=============================================
   7)  RSA Algorithm
   8)  Diffie-Hellman Key Exchange
   9)  MD5 Hash Generation
   13) GPG Email Security (setup + guide)
   16) Wireshark Packet Filters (setup + guide)
   q)  Quit
=============================================
MENU
    read -rp "Which experiment? " exp
    case "$exp" in
        7)  echo; "$PY" "$DIR/exp07_rsa.py";            pause ;;
        8)  echo; "$PY" "$DIR/exp08_diffie_hellman.py"; pause ;;
        9)  echo; "$PY" "$DIR/exp09_md5.py";            pause ;;
        13) sub_menu "Exp 13 - GPG Email Security" exp13_gpg_setup.sh README_exp13_GPG.md; pause ;;
        16) sub_menu "Exp 16 - Wireshark Packet Filters" exp16_wireshark_setup.sh README_exp16_Wireshark.md; pause ;;
        q|Q) echo "Bye!"; exit 0 ;;
        *) echo "Invalid choice."; sleep 1 ;;
    esac
done
